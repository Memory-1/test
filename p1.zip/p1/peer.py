from multiprocessing import Process, freeze_support
from socket import *
import random
import json
import sys
import time

import threading
# Sets up the socket to be open at 127.0.0.1:12000
serverPort = int(sys.argv[1])

# ----------GLOBAL VARS----------



# Server's properties
isLeader = False
ID = random.randint(0, 100000)
# print(ID)
leadersIP = '127.0.0.1'
leadersPort = 0
# leaderCount = 0

# The File Database with IP and PORT
database = {f'{ID}.txt': {'ip': '127.0.0.1', 'port': serverPort}}

file_list = {'files': [f'{ID}.txt', f'{ID+1}.txt', f'{ID}.txt']}
# ------------------------------


def SERVER():
    global ID, leadersIP, leadersPort, isLeader
    """
    This is for when the server starts up. Ready to receive ID's or
    when it's ready to move on.
    """
    # Initializes the Socket
    server = socket(AF_INET, SOCK_STREAM)
    server.bind(("127.0.0.1", serverPort))
    server.listen(3)
    print('The server is ready to receive')

    while True:
        (c, addr) = server.accept()
        # packet = []
        l = c.recv(1024)
        inc_message = l.decode()

        """
        This would get stuck in this loop. I understand that TCP should send it's data in chunks
        So, we should keep receiving in chunks, but I couldn't get it to work
        """
        # while l:
        #     l.recv(1024)
        #     inc_message = inc_message + l.decode()

        """
        This is all of the server logic. It uses a JSON type approach. All messages are expected to 
        come in with a 'type' key and that will determine how the server responds. 
        """
        res = json.loads(inc_message)
        # ---------- Sending A FILE ----------#
        if res['type'] == 'get_file':
            if res['value'] in database:
                f = open(f"Documents/{res['value']}", 'rb')
                l = f.read(1024)
                # Continues to send data in chunks
                while (l):
                    c.send(l)
                    l = f.read(1024)
                c.shutdown(SHUT_WR)
            else:
                message = "Not Found"
                c.send(message.encode())
            c.close()
        # ---------- Requesting file location ----------#
        elif res['type'] == 'request':
            if isLeader:
                if res['value'] in database:
                    # GETS A FILE FROM DATABASE, STRINGIFIES JSON, ENCODES STRING, and SENDS IT
                    c.send(json.dumps(database[res['value']]).encode())
                else:
                    c.send("Not Found".encode())
            else:
                c.send("Contact Leader".encode())
        # ---------- GETTING ID? ----------#
        elif res['type'] == 'get_ID':
            c.send(str(ID).encode())
        # --------------ADDING FILES--------------#
        elif res['type'] == 'add':
            for item in res['value']['files']:
                database[item] = {'ip': addr[0], 'port': addr[1]}

        c.close()


def CLIENT():
    global ID, leadersIP, leadersPort, isLeader, file_list

    # PRESETS
    ports = [12000, 12001, 12002]
    network_database = []

    # Getting IDs
    serverName = '127.0.0.1'
    for port in ports:
        clientSocket = socket(AF_INET, SOCK_STREAM)
        clientSocket.connect((serverName, port))
        message = {'type': 'get_ID'}
        clientSocket.send(json.dumps(message).encode())
        l = clientSocket.recv(1024)
        l = l.decode()
        network_database.append((int(l), port))
        clientSocket.close()

    # Electing a Leader
    """
    I'm using global values, each peer will know whether they are the leader or not. There is logic 
    to also break ties in case of the same random ID. It is done by taking the lower port number.
    I realize in a more real-life situation, I may also defer to the lower IP address.
    """
    network_database.sort(key=lambda node: node[0])
    if network_database[0][0] == network_database[1][0]:
        if network_database[0][1] < network_database[1][1]:
            leadersPort = network_database[0][1]
        else:
            leadersPort = network_database[1][1]
    else:
        leadersPort = network_database[0][1]

    if leadersPort == serverPort:
        isLeader = True

    # print(f"ID: {ID}")
    # print(f"ALL THE IDS AND ASSOCIATED PEERS: {network_database}")
    # print(f"IS LEADER: {isLeader}")

    # Updating the leader with the file list
    """
    I tried sending this data, but as stated above, I had trouble for bytes > 1024
    """
    if not isLeader:
        clientSocket = socket(AF_INET, SOCK_STREAM)
        clientSocket.connect((serverName, leadersPort))
        # message = json.dumps(file_list)
        temp = {'type': 'add', 'value': file_list}
        message = json.dumps(temp)
        clientSocket.send(message.encode)
        clientSocket.close()

threading.Thread(target=SERVER).start()
input("ready? ")
threading.Thread(target=CLIENT).start()


