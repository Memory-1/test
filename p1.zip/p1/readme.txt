Running the program.

1. Navigate to the location where peer.py lives.
2. Open up 3 seperate terminal tabs/windows
3. Run python3 peer.py <PORT NUMBER>
    * It is important that you use ports 12000, 12001, and 12002 because
    these are hard coded into the clients
4. After you have ran the command above, you will see a message that says "Ready?". Hit enter
and this will start the client side of the peer. Do this in each of the tabs/windows. This is done so that
the server-side will have time to get setup so they don't get requests early.


5. TO SEE LEADER ELECTION.
    * Uncomment lines 134-136.
    It works, but the overall program is incomplete. This may help you in your grading process.
     